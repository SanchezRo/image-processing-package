# package_name
image-processing-sanchez

Description. 
The package image-processing-sanchez is used to:
	processing
		-histogram matching
		-structural similarity
		-resize image
	utils
		-read image
		-save image
		-plot image
		-plot result
		-plot histogram

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install package_name

```bash
pip install image-processing-sanchez
```

## Author
Sanchez

## License
[MIT](https://choosealicense.com/licenses/mit/)